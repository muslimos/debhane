# This file contains greeter messages for additional translation
_("Failed to shutdown system")
_("Failed to reboot system")
_("Place your right index finger on the fingerprint reader")
_("Place your left index finger on the fingerprint reader")
